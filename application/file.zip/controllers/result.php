<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Result extends MY_Controller {
    public function index($id = null)
    {
        if($id == null)
        {
            redirect(base_url());
        }
        $question = $this->site_model->get_question_by_id($id);
        if(!isset($question[0]))
        {
            redirect(base_url());
        }
        /*$description = "מה אם - {$question[0]['choice1']}, אבל - {$question[0]['choice2']}, היית לוחץ כל הכפתור או לא? {$question[0]['click']} גולשים לחצו על הכפתור ו-{$question[0]['unclick']} לא לחצו על הכפתור";
        $data = array(
            'description' => $description,
            'title' => 'האם תלחץ על הכפתור?',
            'view' => 'result',
            'data' => array(
                'question' => $question
            )
        );
        $this->load->view('templates/main', $data);*/
        $this->parser->parse("result", ['question' => $question, 'base_url' => base_url()]);
    }
}