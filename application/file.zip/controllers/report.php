<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report extends MY_Controller {
    public function index($id = null)
    {
        if($id == null)
        {
            redirect(base_url());
        }
        $this->form_validation->set_message('required', "חובה למלא את השדה %s");
        $this->form_validation->set_message('min_length', "השדה %s חייב להכיל לפחות %d תווים");
        $this->form_validation->set_message('max_length', "השדה %s יכול להכיל עד %d תווים");
        $this->form_validation->set_rules('title', "כותרת", 'trim|required|xss_clean|htmlspecialchars|min_length[2]|max_length[75]');
        $this->form_validation->set_rules('content', "תוכן", 'trim|required|xss_clean|htmlspecialchars|min_length[5]|max_length[275]');
        if($this->form_validation->run() == FALSE)
        {
            $data = array(
                'add_your_own' => 'חזור',
                'add_your_own_path' => '',
                'title' => 'האם תלחץ על הכפתור?',
                'view' => 'report',
                'data' => array(
                    'question' => $this->site_model->get_question_by_id($id),
                    'message' => validation_errors(),
                    'message_type' => 'error',
                    'report_exists' => $this->site_model->report_exists($id)
                )
            );
            $this->load->view('templates/main', $data);
        }
        else
        {
            $this->site_model->send_report($_POST['title'], $_POST['content'], $id);
            redirect(base_url());
            $data = array(
                'add_your_own' => 'חזור',
                'add_your_own_path' => '',
                'title' => 'האם תלחץ על הכפתור?',
                'view' => 'report',
                'data' => array(
                    'question' => $this->site_model->get_question_by_id($id),
                    'message' => 'הדווח נשלח!',
                    'message_type' => 'success',
                    'report_exists' => $this->site_model->report_exists($id)
                )
            );
            $this->load->view('templates/main', $data);
        }
    }
}