<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends MY_Controller {
    public function index($id = null, $all = "no")
    {
        $bool = true;
        if($id != null)
        {
            $question = $this->site_model->get_question_by_id_approved($id);
            if(isset($question[0]))
            {
                $bool = false;
                $description = "מה אם - {$question[0]['choice1']}, אבל - {$question[0]['choice2']}, היית לוחץ כל הכפתור או לא?";
            }
        }
        
        if($bool) 
        {
            $question = $this->site_model->get_question();
            $description = 'האתר מאפשר לך לבחור למקרים שונים האם היית לוחץ על הכפתור או שלא היית לוחץ על הכפתור';
        }
        
        if($all == "no")
        {
            $data = array(
                'description' => $description,
                'title' => 'האם תלחץ על הכפתור?',
                'view' => 'home',
                'data' => array(
                    'question' => $question
                )
            );
            $this->load->view('templates/main', $data);
        }
        else
        {
            $this->parser->parse("home", ['question' => $question]);
        }
    }
    
    public function instructions()
    {
        $data = array(
            'title' => 'האם תלחץ על הכפתור?',
            'view' => 'instructions',
            'data' => array(
                
            )
        );
        $this->load->view('templates/main', $data);
    }
    
    public function about()
    {
        $data = array(
            'title' => 'האם תלחץ על הכפתור?',
            'view' => 'about',
            'data' => array(
                
            )
        );
        $this->load->view('templates/main', $data);
    }
}