<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Add extends MY_Controller {
    private $curses_array =[];
    public function __construct() {
        parent::__construct();
        $this->curses_array = $this->site_model->get_curses();
    }
    
    public function index()
    {
        $this->form_validation->set_message('required', "חובה למלא את השדה %s");
        $this->form_validation->set_message('min_length', "השדה %s חייב להכיל לפחות %d תווים");
        $this->form_validation->set_message('max_length', "השדה %s יכול להכיל עד %d תווים");
        $this->form_validation->set_rules('if_content', "אם", 'trim|required|xss_clean|htmlspecialchars|min_length[5]|max_length[75]|callback_curses');
        $this->form_validation->set_rules('but_content', "אבל", 'trim|required|xss_clean|htmlspecialchars|min_length[5]|max_length[75]|callback_curses');
        $this->form_validation->set_rules('terms', '...', 'callback_accept_terms');
        $this->form_validation->set_rules('g-recaptcha-response', '.', 'callback_recaptcha');
        if($this->form_validation->run() == FALSE)
        {
            $data = array(
                'description' => 'בעמוד זה תוכל להוסיף בעצמך שאלות לאתר ולהגדיל את חווית השימוש באתר',
                'add_your_own' => 'חזור',
                'add_your_own_path' => '',
                'title' => 'האם תלחץ על הכפתור?',
                'view' => 'add',
                'data' => array(
                    'message' => validation_errors(),
                    'message_type' => 'bg-danger'
                )
            );
            $this->load->view('templates/main', $data);
        }
        else
        {
            $this->site_model->add_question($_POST['if_content'], $_POST['but_content']);
            redirect(base_url());
            $data = array(
                'add_your_own' => 'חזור',
                'add_your_own_path' => '',
                'title' => 'האם תלחץ על הכפתור?',
                'view' => 'add',
                'data' => array(
                    'message' => 'נוצר בהצלחה!',
                    'message_type' => 'success'
                )
            );
            $this->load->view('templates/main', $data);
        }
    }
    
    function accept_terms() 
    {
        if (isset($_POST['terms'])) return true;
        $this->form_validation->set_message('accept_terms', 'חייב לאשר את תנאי השימוש');
        return false;
    }
    
    function curses($str)
    {
        foreach ($this->curses_array as $curse) 
        {
            if(strpos($str, $curse) !== false)
            {
                $this->form_validation->set_message('curses', 'השדה %s מכיל מילה גסה');
                return false;
            }
        }
        return true;
    }
    
    function recaptcha()
    {
        $this->form_validation->set_message('recaptcha', 'אנא אמת שאינך רובוט');
        if(isset($_POST['g-recaptcha-response']))
        {
            $secret = "6LeiUB8TAAAAAG8wE7nXGiX9ucpG2BP5aL1wpHF3";
            $response = $_POST['g-recaptcha-response'];
            $remoteip = $_SERVER['REMOTE_ADDR'];
            $data = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secret}&response={$response}&remoteip={$remoteip}");
            $json = json_decode($data, TRUE);
            return $json['success'];
        }
        return false;
    }
}