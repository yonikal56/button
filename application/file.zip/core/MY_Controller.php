<?php

class MY_Controller extends CI_Controller {
    public $lang_long_name;
    public $lang_short_name;
    
    public function __construct() {
        parent::__construct();
        $language = "hebrew";
        if($this->uri->segment(1) == "en")
        {
            $language = "english";
        }
        $languages = ['english' => 'en', 'hebrew' => 'he'];
        $this->lang->load("site", $language);
        $this->CI = get_instance();
        $this->lang_long_name = $language;
        $this->lang_short_name = $languages[$language];
    }
}