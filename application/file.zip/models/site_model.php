<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_model extends CI_Model {
    private $site_lang;
    
    public function __construct() {
        parent::__construct();
        $language = "hebrew";
        if($this->uri->segment(1) == "en")
        {
            $language = "english";
        }
        $langs_segment = ['hebrew' => 'he', 'english' => 'en'];
        $this->site_lang = $langs_segment[$language];
    }
    
    public function add_question($if, $but)
    {
        $this->db->insert("questions", [
            'choice1' => $if,
            'choice2' => $but,
            'click' => 0,
            'unclick' => 0,
            'like' => 0,
            'unlike' => 0,
            'adder_IP' => $_SERVER['REMOTE_ADDR'],
            'deleted' => 0,
            'approved' => 0
        ]);
    }
    
    public function get_user_details($username)
    {
        $this->db->where("username", $username);
        $query = $this->db->get('users');
        return $query->result_array();
    }
    
    public function check_details($username, $password, $passworeded = true)
    {
        $user = $this->get_user_details($username);
        if(count($user) == 1)
        {
            $user = $user[0];
            $pass_to_check = ($passworeded ? $password : pass($password, $user['salt']));
            if($user['password'] == $pass_to_check)
            {
                return true;
            }
        }
        return false;
    }
    
    public function login($username, $password)
    {
        if($this->check_details($username, $password, false))
        {
            $user = $this->get_user_details($username)[0];
            set_cookie('button_user', $username, time() + 60*60*24*30);
            set_cookie('button_pass', $user['password'], time() + 60*60*24*30);
            redirect(base_url());
        }
        return false;
    }
    
    public function is_admin()
    {
        if($this->if_connected())
        {
            $user = $this->get_user_details(get_cookie('button_user'))[0];
            if($user['is_admin'] == 1)
            {
                return true;
            }
        }
        return false;
    }
    
    public function if_connected()
    {
        if(get_cookie('button_user') && get_cookie('button_pass'))
        {
            if($this->check_details(get_cookie('button_user'), get_cookie('button_pass')))
            {
                return true;
            }
            $this->logout();
            redirect(base_url());
        }
        return false;
    }
    
    public function add_curse($curse)
    {
        $this->db->insert('curses', ['curse' => $curse]);
    }
    
    public function get_curses_array()
    {
        return $this->db->get('curses')->result_array();
    }
    
    public function edit_question($choice1, $choice2, $id)
    {
        $this->db->update('questions', ['choice1' => $choice1, 'choice2' => $choice2], ['ID' => $id]);
    }
    
    public function get_questions_array($page = null)
    {
        if($page != null)
        {
            return $this->db->get_where('questions', ['deleted' => 0], 50, ($page-1)*50)->result_array();
        }
        return $this->db->get_where('questions', ['deleted' => 0])->result_array();
    }
    
    public function get_questions_unapproved_array($page = null)
    {
        if($page != null)
        {
            return $this->db->get_where('questions', ['deleted' => 0, 'approved' => 0], 50, ($page-1)*50)->result_array();
        }
        return $this->db->get_where('questions', ['deleted' => 0, 'approved' => 0])->result_array();
    }
    
    public function get_reports_array()
    {
        return $this->db->get('reports')->result_array();
    }
    
    public function get_report_question_id($id)
    {
        $report = $this->db->get_where('reports', ['ID' => $id])->result_array();
        return $report[0]['question_ID'];
    }
    
    public function remove_curse($id)
    {
        $this->db->delete('curses', ['ID' => $id]);
    }
    
    public function remove_report($id)
    {
        $this->db->delete('reports', ['ID' => $id]);
    }
    
    public function logout()
    {
        delete_cookie('button_user');
        delete_cookie('button_pass');
    }
    
    public function register($username, $email, $password)
    {
        $salt = random_salt();
        $this->db->insert("users", [
            'username' => $username,
            'email' => $email,
            'salt' => $salt,
            'password' => pass($password, $salt),
            'ok' => 1,
            'IP' => $_SERVER['REMOTE_ADDR'],
            'is_admin' => 0
        ]);
    }
    
    public function get_curses()
    {
        $curses = [];
        $query = $this->db->get("curses");
        $result = $query->result_array();
        foreach ($result as $curse)
        {
            $curses[] = $curse['curse'];
        }
        return $curses;
    }
    
    public function get_question()
    {
        $this->db->order_by('ID', 'RANDOM');
        $this->db->limit(1);
        $this->db->where("deleted", 0);
        $this->db->where("approved", 1);
        $query = $this->db->get('questions');
        return $query->result_array();
    }
    
    public function click($id, $pos)
    {
        if($pos == "yes")
        {
            $this->db->set("click", "click+1", FALSE);
        }
        else
        {
            $this->db->set("unclick", "unclick+1", FALSE);
        }
        $this->db->where("ID", $id);
        $this->db->update('questions');
    }
    
    public function like($id, $pos)
    {
        if($pos == "yes")
        {
            $this->db->set("like", "`like`+1", FALSE);
        }
        else
        {
            $this->db->set("unlike", "`unlike`+1", FALSE);
            $question = $this->get_question_by_id($id);
            if($question[0]['unlike'] >= 149 && $question[0]['approved'] == 0)
            {
                $this->db->set("deleted", 1);
            }
        }
        $this->db->where("ID", $id);
        $this->db->update('questions');
    }
    
    public function get_question_by_id_approved($id)
    {
        $this->db->where("ID", $id);
        $this->db->where("deleted", 0);
        $this->db->where("approved", 1);
        $query = $this->db->get("questions", 1);
        return $query->result_array(); 
    }
    
    public function get_question_by_id($id)
    {
        $this->db->where("ID", $id);
        $this->db->where("deleted", 0);
        $query = $this->db->get("questions", 1);
        return $query->result_array(); 
    }
    
    public function send_report($title, $content, $id)
    {
        $question = $this->get_question_by_id($id);
        $this->db->insert("reports", [
            'question_ID' => $id,
            'title' => $title,
            'content' => $content,
            'sender_IP' => $_SERVER['REMOTE_ADDR']
        ]);
    }
    
    public function report_exists($question_ID)
    {
        $this->db->where("question_ID", $question_ID);
        $query = $this->db->get('reports');
        return count($query->result_array()) >= 1;
    }
    
    public function remove_question($id)
    {
        $this->db->update("questions", ['deleted' => 1], ['ID' => $id]);
    }
    
    public function approve_question($id)
    {
        $this->db->update("questions", ['approved' => 1], ['ID' => $id]);
    }
}