<table border="1">
    <tr>
        <th>Tab Name</th>
        <th>Page Name</th>
        <th>Remove</th>
        <th>Edit</th>
        <th>Move Up</th>
        <th>Move Right</th>
    </tr>
    {tabs}
        <tr>
            <td>{name}</td>
            <td>{page}</td>
            <td><a href="{base_url}admin/managetabs/remove_tab/{ID}">Remove Tab</a></td>
            <td><a href="{base_url}admin/managetabs/edit_tab/{ID}">Edit Tab</a></td>
            <td><a href="{base_url}admin/managetabs/change_order/{ID}/up">Move Tab Up</a></td>
            <td><a href="{base_url}admin/managetabs/change_order/{ID}/down">Move Tab Down</a></td>
        </tr>
    {/tabs}
</table>
<a href="{base_url}admin/managetabs/add_tab">Add Tab</a>