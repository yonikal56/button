<a href="{base_url}admin/managepages">Manage Pages</a><br>
<a href="{base_url}admin/managetabs">Manage Tabs</a><br>