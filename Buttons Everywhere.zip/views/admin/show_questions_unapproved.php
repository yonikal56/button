<table border="1" align="center">
    <tr>
        <th>מזהה</th>
        <th>אם</th>
        <th>אבל</th>
        <th>לחצו</th>
        <th>לא לחצו</th>
        <th>אהבו</th>
        <th>לא אהבו</th>
        <th>IP מוסיף</th>
        <th>אושר</th>
        <th>ערוך</th>
        <th>מחק</th>
        <th>אשר</th>
    </tr>
    {questions}
    <tr>
        <td>{ID}</td>
        <td style="max-width: 15%; word-break: break-all;">{choice1}</td>
        <td style="max-width: 15%; word-break: break-all;">{choice2}</td>
        <td>{click}</td>
        <td>{unclick}</td>
        <td>{like}</td>
        <td>{unlike}</td>
        <td>{adder_IP}</td>
        <td>{approved}</td>
        <td><a href="{base_url}admin/unapproved/edit/{ID}">ערוך</a></td>
        <td><a href="{base_url}admin/unapproved/delete/{ID}">מחק</a></td>
        <td><a href="{base_url}admin/unapproved/approve/{ID}">אשר</a></td>
    </tr>
    {/questions}
</table>
{pagination}