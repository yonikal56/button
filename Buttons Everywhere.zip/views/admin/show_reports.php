<table border="1" align="center">
    <tr>
        <th>כותרת</th>
        <th>תוכן</th>
        <th>IP</th>
        <th>אם</th>
        <th>אבל</th>
        <th>ID שאלה</th>
        <th>מחק שאלה</th>
        <th>ערוך שאלה</th>
        <th>אשר שאלה</th>
        <th>מחק דווח</th>
    </tr>
    {reports}
    <tr>
        <td style="max-width: 10%; word-break: break-all;">{title}</td>
        <td style="max-width: 10%; word-break: break-all;">{content}</td>
        <td>{sender_IP}</td>
        <td style="max-width: 10%; word-break: break-all;">{choice1}</td>
        <td style="max-width: 10%; word-break: break-all;">{choice2}</td>
        <td>{question_ID}</td>
        <td><a href="{base_url}admin/reports/delete_question/{ID}">מחק שאלה</a></td>
        <td><a href="{base_url}admin/reports/edit_question/{ID}">ערוך שאלה</a></td>
        <td><a href="{base_url}admin/reports/approve_question/{ID}">אשר שאלה</a></td>
        <td><a href="{base_url}admin/reports/delete/{ID}">מחק דווח</a></td>
    </tr>
    {/reports}
</table>