<table border="1">
    <tr>
        <th>Page Name</th>
        <th>Remove</th>
        <th>Edit</th>
    </tr>
    {pages}
        <tr>
            <td>{name}</td>
            <td><a href="{base_url}admin/managepages/remove_page/{ID}">Remove Page</a></td>
            <td><a href="{base_url}admin/managepages/edit_page/{ID}">Edit Page</a></td>
        </tr>
    {/pages}
</table>
<a href="{base_url}admin/managepages/add_page">Add Page</a>