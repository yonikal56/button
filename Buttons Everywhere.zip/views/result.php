{question}    
    <section class="col-md-12 panel panel-default contentSpace">
        <div class="result_part">{click} {$lang.clicked}{unclick} {$lang.didnt_clicked}</div><br>
        <span class="text">{$lang.for_next_question}</span>
        <br><br>
        <div class="liked_unliked_wrapper">
            <div class="col-md-1"></div>
            <div class="col-md-3">
                <div class="likeButton"><a href="#" id="{ID}" data-bool="yes"><h4 class="likesButtons">{$lang.like_it_sentence}</h4></a></div>
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- Yoni - 320 -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:256px;height:100px"
					 data-ad-client="ca-pub-1220301400794390"
					 data-ad-slot="9340856263"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
				<h4 class="likeText">{like} {$lang.like_it}</h4>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-3">
                <div class="unlikeButton"><a href="#" id="{ID}" data-bool="no"><h4 class="likesButtons">{$lang.unlike_it_sentence}</h4></a></div>
				<div class="ifMobile"><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- Yoni - 320 -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:256px;height:100px"
					 data-ad-client="ca-pub-1220301400794390"
					 data-ad-slot="9340856263"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
				</div>
				<h4 class="likeText">{unlike} {$lang.unlike_it}</h4>
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
    <div class="clr"></div>
{/question}