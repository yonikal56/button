<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>{title}</title>
        <!-- CSS Files -->
        <link href="{base_url}css/website.css" rel="stylesheet" type="text/css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="keywords" content="{keywords}">
        <meta name="description" content="{description}">
    </head>

    <body style="background: url({base_url}images/bg.jpg) top center no-repeat;">
        <!-- Logo -->
        <header class="logo container">
            <a href="{base_url}"><img src="{base_url}images/logo.png" alt=""></a>
        </header>

        <!-- Main Content Container -->
        <main class="container main">
        <!-- Start Of Main Content -->