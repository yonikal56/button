{page}
<form action="{base_url}admin/managepages/edit_page/{ID}" method="post" class='contact_form'>
    Tab Name:<input type='text' name='name' value="<?= set_value('name', '{name}') ?>"><br><br>
    <center>
        Content:<br><textarea name='html'><?= set_value('html', '{html}') ?></textarea><br><br>
    </center>
    Description:<br><textarea name="description"><?= set_value('description', '{description}') ?></textarea><br><br>
    Keywords:<input type="text" name="keywords" value="<?= set_value('keywords', '{keywords}') ?>"><br><br>
    <input type="hidden" name="id" value="{ID}">
    <input type='submit' value='Edit Page'>
</form><br>
<div class="{message_class}">{message}</div><br>
<a href="{base_url}admin/managepages">Back to pages</a>
<script src="//cdn.ckeditor.com/4.5.1/standard/ckeditor.js"></script>
<script>
CKEDITOR.replace( 'html' );
CKEDITOR.config.allowedContent = true;
</script>
{/page}