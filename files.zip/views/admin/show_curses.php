<table border="1" align="center">
    <tr>
        <th>מילה</th>
        <th>מחיקה</th>
    </tr>
    {curses}
    <tr>
        <td>{curse}</td>
        <td><a href="{base_url}admin/curses/delete/{ID}">מחק</a></td>
    </tr>
    {/curses}
    <form action="" method="post">
        קללה : <input type="text" name="curse"><br>
        <input type="submit" value="הוסף"><br>
    </form>
</table>