<form action="{base_url}admin/managetabs/add_tab" method="post" class='contact_form'>
    Tab Name:<input type='text' name='name' value="<?= set_value('name') ?>"><br><br>
    Page Name:<input type='text' name='page' value="<?= set_value('page') ?>"><br><br>
    <input type='submit' value='Add Tab'>
</form><br>
<div class="{message_class}">{message}</div><br>
<a href="{base_url}admin/managetabs">Back to tabs</a>