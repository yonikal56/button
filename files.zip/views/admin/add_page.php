<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>
<script>
    tinymce.init({
        selector:'textarea[name="html"]',
        width: 850
    });
</script>
<form action="{base_url}admin/managepages/add_page" method="post" class='contact_form'>
    Tab Name:<input type='text' name='name' value="<?= set_value('name') ?>"><br><br>
    <center>
        Content:<br><textarea name='html'><?= set_value('html') ?></textarea><br>
    </center>
    <input type='submit' value='Add Page'>
</form><br>
<div class="{message_class}">{message}</div><br>
<a href="{base_url}admin/managepages">Back to pages</a>