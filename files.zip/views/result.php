{question}    
    <section class="col-md-12 panel panel-default contentSpace">
        <div class="result_part">{click} לחצו על הכפתור ו{unclick} לא לחצו על הכפתור בשאלה הזו</div><br>
        <span class="text">בשביל להמשיך לשאלה הבאה, בחר אם אהבת את השאלה</span>
        <br><br>
        <div class="liked_unliked_wrapper">
            <div class="col-md-1"></div>
            <div class="col-md-3">
                <div class="likeButton"><a href="#" id="{ID}" data-bool="yes"><h4 class="likesButtons">אהבתי את השאלה</h4></a></div>
				<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- Yoni - 320 -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:256px;height:100px"
					 data-ad-client="ca-pub-1220301400794390"
					 data-ad-slot="9340856263"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
				<h4 class="likeText">{like} אהבו</h4>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-3">
                <div class="unlikeButton"><a href="#" id="{ID}" data-bool="no"><h4 class="likesButtons">לא אהבתי את השאלה</h4></a></div>
				<div class="ifMobile"><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
				<!-- Yoni - 320 -->
				<ins class="adsbygoogle"
					 style="display:inline-block;width:256px;height:100px"
					 data-ad-client="ca-pub-1220301400794390"
					 data-ad-slot="9340856263"></ins>
				<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
				</script>
				</div>
				<h4 class="likeText">{unlike} לא אהבו</h4>
            </div>
            <div class="col-md-1"></div>
        </div>
    </section>
    <div class="clr"></div>
{/question}