<?php
//Hebrew
//$lang['key'] = "value";
$lang = [
    'if' => 'מה אם',
    'but' => 'אבל',
    'add' => 'הוסף',
    'yes' => 'הייתי לוחץ'
];