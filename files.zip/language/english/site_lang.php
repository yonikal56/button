<?php
//English
//$lang['key'] = "value";
$lang = [
    'if' => 'What if',
    'but' => 'But',
    'add' => 'add',
    'yes' => 'I will click'
];